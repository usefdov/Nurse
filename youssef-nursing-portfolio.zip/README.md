# Youssef Mamdouh Mokhtar — Nursing Portfolio

Premium, responsive Next.js portfolio concept.

## Stack
- Next.js
- React
- TypeScript
- Tailwind CSS
- Framer Motion
- Lucide Icons

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Notes
All contact information, social links, experience details, projects, learning items, and statistics are explicitly presented as fictional/demo portfolio content where appropriate. The profile image area is intentionally a placeholder.
